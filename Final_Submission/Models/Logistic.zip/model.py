import numpy as np
from sklearn.impute import SimpleImputer
from sklearn.linear_model import LogisticRegression
from sklearn.preprocessing import StandardScaler


class Model:
    def __init__(self):
        self.drop_cols = {"CompNo"}
        self.feature_cols = None
        self.imputer = SimpleImputer(strategy="median")
        self.scaler = StandardScaler()
        self.use_scaler = True
        self.class_prior = np.array([1 / 3, 1 / 3, 1 / 3], dtype=float)
        self.is_fitted = False
        self.backend = "logistic"

        self.fallback_model = LogisticRegression(
            solver="lbfgs",
            C=2.3497186021096423,
            max_iter=2000,
            class_weight=None,
            random_state=42,
        )
        self.model = self.fallback_model

    @staticmethod
    def _to_float(value):
        if value is None:
            return np.nan
        if isinstance(value, bool):
            return 1.0 if value else 0.0
        try:
            return float(value)
        except Exception:
            text = str(value).strip().lower()
            if text in {"", "nan", "none", "null"}:
                return np.nan
            if text == "true":
                return 1.0
            if text == "false":
                return 0.0
            try:
                return float(text)
            except Exception:
                return np.nan

    def _prepare_matrix(self, X, fit=False):
        if hasattr(X, "columns"):
            if fit or self.feature_cols is None:
                cols = [c for c in X.columns if (c not in self.drop_cols and not c.startswith("y_"))]
                self.feature_cols = cols if cols else list(X.columns)
            cols = [c for c in self.feature_cols if c in X.columns]
            frame = X[cols].copy() if cols else X.copy()
            for col in frame.columns:
                frame[col] = [self._to_float(v) for v in frame[col].values]

            if "mm" in frame.columns:
                mm = np.clip(frame["mm"].astype(float), 1.0, 12.0)
                frame["mm_sin"] = np.sin(2.0 * np.pi * mm / 12.0)
                frame["mm_cos"] = np.cos(2.0 * np.pi * mm / 12.0)

            for col in ["dtdlevel", "dtdtrend", "DTDmedianNonFin", "sigma", "m2b", "ni2talevel", "liqnonfinlevel"]:
                if col in frame.columns:
                    v = frame[col].astype(float)
                    frame[f"{col}_logabs"] = np.sign(v) * np.log1p(np.abs(v))

            if "dtdlevel" in frame.columns and "dtdtrend" in frame.columns:
                frame["dtd_interaction"] = frame["dtdlevel"].astype(float) * frame["dtdtrend"].astype(float)

            arr = frame.to_numpy(dtype=float)
        else:
            arr = np.asarray(X, dtype=float)

        if arr.ndim == 0:
            arr = arr.reshape(1, 1)
        elif arr.ndim == 1:
            arr = arr.reshape(arr.shape[0], 1)
        elif arr.ndim > 2:
            arr = arr.reshape(arr.shape[0], -1)
        arr[~np.isfinite(arr)] = np.nan
        return arr

    def _transform(self, X, fit=False):
        arr = self._prepare_matrix(X, fit=fit)
        if fit:
            arr = self.imputer.fit_transform(arr)
            if self.use_scaler:
                arr = self.scaler.fit_transform(arr)
        else:
            arr = self.imputer.transform(arr)
            if self.use_scaler:
                arr = self.scaler.transform(arr)
        return arr

    def _fit_fallback(self, X_arr, y):
        self.model = self.fallback_model
        self.backend = "logistic_fallback"
        self.use_scaler = True
        self.model.fit(X_arr, y)

    def fit(self, X, y):
        y = np.asarray(y).ravel().astype(int)
        if y.size == 0:
            self.is_fitted = True
            return self

        counts = np.bincount(np.clip(y, 0, 2), minlength=3).astype(float)
        if counts.sum() > 0:
            self.class_prior = counts / counts.sum()

        X_arr = self._transform(X, fit=True)
        if np.unique(y).size >= 2:
            try:
                self.model.fit(X_arr, y)
            except Exception:
                self._fit_fallback(X_arr, y)
        self.is_fitted = True
        return self

    def predict_proba(self, X):
        n = int(len(X)) if hasattr(X, "__len__") else 1
        if n == 0:
            return np.zeros((0, 3), dtype=float)

        base = np.tile(self.class_prior.reshape(1, 3), (n, 1))
        if not self.is_fitted:
            return base

        X_arr = self._transform(X, fit=False)
        try:
            raw = self.model.predict_proba(X_arr)
            out = np.zeros((raw.shape[0], 3), dtype=float)
            classes = np.asarray(getattr(self.model, "classes_", []), dtype=int)
            for i, cls in enumerate(classes):
                if 0 <= cls <= 2:
                    out[:, int(cls)] = raw[:, i]
            if out.shape[0] != n:
                return base
            out[~np.isfinite(out)] = 0.0
            row_sum = out.sum(axis=1, keepdims=True)
            good = row_sum.squeeze() > 0
            out[good] = out[good] / row_sum[good]
            out[~good] = base[~good]
            return out
        except Exception:
            return base

    def predict(self, X):
        return np.argmax(self.predict_proba(X), axis=1).astype(int)
