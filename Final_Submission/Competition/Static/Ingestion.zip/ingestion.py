
import glob
import os
import re
import sys

import numpy as np
import pandas as pd


def _pick_csv(input_dir, patterns, preferred_names=()):
    candidates = []
    for pattern in patterns:
        candidates.extend(glob.glob(os.path.join(input_dir, pattern)))
        candidates.extend(glob.glob(os.path.join(input_dir, "**", pattern), recursive=True))
    candidates = [
        path
        for path in candidates
        if os.path.isfile(path) and not os.path.basename(path).startswith("._")
    ]
    if not candidates:
        return None

    by_name = {os.path.basename(path): path for path in candidates}
    for preferred_name in preferred_names:
        if preferred_name in by_name:
            return by_name[preferred_name]

    candidates = sorted(candidates, key=lambda path: (len(os.path.basename(path)), os.path.basename(path)))
    return candidates[0]


def _find_train_and_test(input_dir):
    train_path = _pick_csv(
        input_dir,
        patterns=["train*.csv", "*train*.csv"],
        preferred_names=["train.csv", "train_labeled_upto2014.csv"],
    )
    test_path = _pick_csv(
        input_dir,
        patterns=["test*.csv", "*test*.csv"],
        preferred_names=["test_features_from2015.csv", "test.csv"],
    )
    if train_path is None:
        raise FileNotFoundError(
            f"No training split CSV found in {input_dir}. Expected files like train.csv / train_*.csv."
        )
    if test_path is None:
        raise FileNotFoundError(
            f"No testing split CSV found in {input_dir}. Expected files like test.csv / test_*.csv."
        )
    return train_path, test_path


def _is_label_col(column_name):
    return bool(re.match(r"^y_\d+m$", str(column_name)))


def _pick_target_column(train_df):
    target_col = os.environ.get("TARGET_COL", "y_12m")
    if target_col in train_df.columns:
        return target_col

    label_cols = [column for column in train_df.columns if _is_label_col(column)]
    if not label_cols:
        raise ValueError(
            f"Training split has no y_*m label column. Columns: {list(train_df.columns)}"
        )
    if "y_12m" in label_cols:
        return "y_12m"
    return sorted(label_cols, key=lambda name: int(name.split("_")[1][:-1]))[0]


def _normalize_proba(probabilities):
    array = np.asarray(probabilities)
    if array.ndim == 1:
        p1 = array
        p0 = 1 - p1
        p2 = np.zeros_like(p1)
        return p0, p1, p2

    if array.shape[1] >= 3:
        return array[:, 0], array[:, 1], array[:, 2]
    if array.shape[1] == 2:
        p0 = array[:, 0]
        p1 = array[:, 1]
        p2 = np.zeros_like(p1)
        return p0, p1, p2

    p1 = array[:, 0]
    p0 = 1 - p1
    p2 = np.zeros_like(p1)
    return p0, p1, p2


def _pick_key_columns(test_df):
    preferred_keys = [column for column in ["CompNo", "yyyy", "mm"] if column in test_df.columns]
    if preferred_keys:
        return preferred_keys

    fallback_keys = [column for column in test_df.columns if not _is_label_col(column)]
    if not fallback_keys:
        raise ValueError("Test split has no usable columns for prediction keys.")
    return fallback_keys[:3]


def main(input_dir, output_dir, submission_dir):
    sys.path.insert(0, submission_dir)
    from model import Model

    train_path, test_path = _find_train_and_test(input_dir)
    train_df = pd.read_csv(train_path)
    test_df = pd.read_csv(test_path)

    target_col = _pick_target_column(train_df)
    feature_cols = [column for column in train_df.columns if column != target_col and column in test_df.columns]
    if not feature_cols:
        raise ValueError("No overlapping feature columns between train/test splits.")

    x_train = train_df[feature_cols]
    y_train = train_df[target_col]
    x_test = test_df.reindex(columns=feature_cols, fill_value=0)

    model = Model().fit(x_train, y_train)
    probabilities = model.predict_proba(x_test)
    p0, p1, p2 = _normalize_proba(probabilities)

    key_cols = _pick_key_columns(test_df)
    output_df = test_df[key_cols].copy()
    output_df["p0"] = p0
    output_df["p1"] = p1
    output_df["p2"] = p2

    os.makedirs(output_dir, exist_ok=True)
    output_df.to_csv(os.path.join(output_dir, "predictions.csv"), index=False)


if __name__ == "__main__":
    main(sys.argv[1], sys.argv[2], sys.argv[3])
